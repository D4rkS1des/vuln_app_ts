import React from 'react';
import './App.css';
import { useState } from 'react'
import DangerouslySetHtmlContent from "./containers/dangerous";

export function App() {

    const [content, setContent] = useState(`
    <div>This wil be rendered</div>
  ` + <DangerouslySetHtmlContent html={navigator.userAgent} />
    )
    const updatedHtml = `
    <div>Look at the console now!</div>
    <script>
      console.log(navigator.userAgent)
    </script>
  `
    return (
        <div>
            <DangerouslySetHtmlContent style={{color: "white", background: "red"}} html={content} />
            <button onClick={() => setContent(updatedHtml)}>Hit here to see magic!</button>
        </div>
    );
}

export default App
